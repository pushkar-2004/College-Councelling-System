I HAVE MADE A SIMPLE FRONTEND PAGE.
Tables mei Primary key foreign key added nhi hai
Tools ke andar rank and college predictor ke css mei ek problem hai.
